"""Evidence-linked replay summarization."""
