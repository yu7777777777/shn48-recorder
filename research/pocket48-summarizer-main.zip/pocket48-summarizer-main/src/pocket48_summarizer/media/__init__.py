"""Media inspection and extraction."""
